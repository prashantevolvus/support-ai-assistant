import React, { useState } from "react";
import axios from "axios";

function App() {
  const [file, setFile] = useState(null);
  const [chat, setChat] = useState([]);
  const [input, setInput] = useState("");

  // Handle file upload to backend
  const uploadFile = async () => {
    if (!file) {
      alert("Please select a file to upload.");
      return;
    }
    const formData = new FormData();
    formData.append("file", file);
    try {
      await axios.post("http://localhost:8000/upload/", formData, {
        headers: { "Content-Type": "multipart/form-data" },
      });
      alert("Data uploaded successfully");
    } catch (error) {
      console.error("Failed to upload file:", error);
      alert("There was an error uploading your file.");
    }
  };

  // Send user question to backend
  const sendMessage = async () => {
    const question = input.trim();
    if (!question) return;
    const userMessage = { role: "user", content: question };
    setChat((c) => [...c, userMessage]);
    setInput("");
    try {
      const res = await axios.post("http://localhost:8000/chat/", {
        question,
      });
      const botMessage = { role: "bot", content: res.data.answer };
      setChat((c) => [...c, botMessage]);
    } catch (error) {
      console.error("Failed to get response:", error);
      const errorMsg = {
        role: "bot",
        content: "Sorry, I encountered an error processing your request.",
      };
      setChat((c) => [...c, errorMsg]);
    }
  };

  return (
    <div className="p-6 max-w-3xl mx-auto">
      <h1 className="text-2xl font-bold mb-4">Support AI Assistant</h1>

      <div className="mb-4">
        <input
          type="file"
          accept=".csv"
          onChange={(e) => setFile(e.target.files[0])}
          className="mr-2"
        />
        <button
          onClick={uploadFile}
          className="bg-green-500 text-white px-4 py-1 rounded"
        >
          Upload Data
        </button>
      </div>

      <div className="border p-4 mb-4 h-80 overflow-y-auto bg-gray-50 rounded">
        {chat.map((msg, i) => (
          <div
            key={i}
            className={
              msg.role === "user" ? "text-right mb-2" : "text-left mb-2"
            }
          >
            <p
              className={
                msg.role === "user"
                  ? "bg-blue-200 inline-block p-2 rounded"
                  : "bg-gray-200 inline-block p-2 rounded"
              }
            >
              {msg.content}
            </p>
          </div>
        ))}
      </div>

      <div className="flex">
        <input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter") sendMessage();
          }}
          className="flex-1 border p-2 rounded-l"
          placeholder="Ask a question..."
        />
        <button
          onClick={sendMessage}
          className="bg-blue-500 text-white px-4 rounded-r"
        >
          Send
        </button>
      </div>
    </div>
  );
}

export default App;
